import 'package:flutter/material.dart';

class AddProductScreen extends StatefulWidget {
  static const route = 'addProduct';

  @override
  _AddProductScreenState createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Product"),
        centerTitle: true,
      ),
      body: Container(),
    );
  }
}
