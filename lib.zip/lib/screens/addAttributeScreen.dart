import 'package:flutter/material.dart';
import 'package:practical_task_interview/helper/db_helper.dart';
import 'package:practical_task_interview/models/attribute_model.dart';

class AddAttributeScreen extends StatefulWidget {
  static const route = 'addAttribute';

  @override
  _AddAttributeScreenState createState() => _AddAttributeScreenState();
}

class _AddAttributeScreenState extends State<AddAttributeScreen> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController _atribute = TextEditingController();
  late Future fetchAttribute;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchAttribute = dbh.getAllAttribute();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(" Attribute"),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          openForm();
        },
        child: Icon(Icons.add),
      ),
      body: SafeArea(
        child: Container(
          child: FutureBuilder(
            builder: (context, AsyncSnapshot ss) {
              if (ss.hasError) {
                return Center(
                  child: Text("ERROR: ${ss.error}"),
                );
              } else {
                if (ss.hasData) {
                  List<Attribute> data = ss.data;
                  return ListView.builder(
                    itemCount: data.length,
                    itemBuilder: (context, i) {
                      return ListTile(
                        leading: Text("${data[i].id}"),
                        title: Text("${data[i].attribute}"),
                        trailing: Wrap(
                          children: [
                            IconButton(
                              icon: Icon(
                                Icons.edit,
                                color: Colors.blue,
                              ),
                              onPressed: () {
                                // TODO: Update Student data
                              },
                            ),
                            IconButton(
                                icon: Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      title: Text("Delete Record"),
                                      content: Text(
                                          "Are you sure to delete this record?"),
                                      actions: [
                                        ElevatedButton(
                                          child: Text("Delete"),
                                          onPressed: () async {},
                                          style: ElevatedButton.styleFrom(
                                              primary: Colors.redAccent,
                                              onPrimary: Colors.white),
                                        ),
                                        OutlinedButton(
                                          child: Text("Cancel"),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                          ],
                        ),
                      );
                    },
                  );
                } else {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
              }
            },
          ),
        ),
      ),
    );
  }

  openForm() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Add Attribute"),
            content: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    validator: (val) {
                      if (val!.isEmpty) {
                        return "Please enter Attribute .....";
                      }
                      return null;
                    },
                    controller: _atribute,
                    decoration: InputDecoration(
                      hintText: "Enter Attribute",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              OutlinedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text("cancel"),
              ),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    int number = await dbh.insertData(
                      s: Attribute(
                        attribute: _atribute.text,
                      ),
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Data inserted at Id: $number"),
                      ),
                    );
                  }
                },
                child: Text("Add"),
              ),
            ],
          );
        });
  }

  refreshData() {
    fetchAttribute = dbh.getAllAttribute();
  }
}
